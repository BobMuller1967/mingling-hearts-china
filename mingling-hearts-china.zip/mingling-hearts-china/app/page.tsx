"use client";
import { useState } from "react";

export default function Page() {
  const [menuOpen, setMenuOpen] = useState(false);

  return (
    <div className="min-h-screen bg-neutral-50 text-neutral-900">
      {/* Nav */}
      <header className="sticky top-0 z-50 backdrop-blur bg-white/80 border-b border-neutral-200">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <div className="flex h-16 items-center justify-between">
            <a href="#home" className="flex items-center gap-3">
              <div className="h-9 w-9 rounded-xl bg-rose-600 flex items-center justify-center text-white font-bold">♥</div>
              <span className="font-extrabold tracking-tight text-lg sm:text-xl">Mingling Hearts China</span>
            </a>
            <nav className="hidden md:flex items-center gap-8 text-sm font-medium">
              <a href="#how" className="hover:text-rose-700">How it works</a>
              <a href="#values" className="hover:text-rose-700">Our values</a>
              <a href="#stories" className="hover:text-rose-700">Stories</a>
              <a href="#safety" className="hover:text-rose-700">Safety</a>
              <a href="#contact" className="rounded-full bg-rose-600 px-4 py-2 text-white hover:bg-rose-700">Get started</a>
            </nav>
            <button
              className="md:hidden inline-flex items-center justify-center rounded-xl p-2 hover:bg-neutral-100"
              onClick={() => setMenuOpen(v => !v)}
              aria-label="Open menu"
            >
              <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" className="h-6 w-6"><path d="M3.75 6.75h16.5v1.5H3.75v-1.5Zm0 4.5h16.5v1.5H3.75v-1.5Zm0 4.5h16.5v1.5H3.75v-1.5Z"/></svg>
            </button>
          </div>
        </div>
        {/* Mobile menu */}
        {menuOpen && (
          <div className="md:hidden border-t border-neutral-200 bg-white">
            <div className="mx-auto max-w-7xl px-4 py-4 grid gap-3">
              <a onClick={()=>setMenuOpen(false)} href="#how" className="py-2">How it works</a>
              <a onClick={()=>setMenuOpen(false)} href="#values" className="py-2">Our values</a>
              <a onClick={()=>setMenuOpen(false)} href="#stories" className="py-2">Stories</a>
              <a onClick={()=>setMenuOpen(false)} href="#safety" className="py-2">Safety</a>
              <a onClick={()=>setMenuOpen(false)} href="#contact" className="rounded-xl bg-rose-600 px-4 py-2 text-white text-center">Get started</a>
            </div>
          </div>
        )}
      </header>

      {/* Hero */}
      <section id="home" className="relative overflow-hidden">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 py-16 sm:py-24 grid lg:grid-cols-2 gap-12 items-center">
          <div>
            <h1 className="text-4xl sm:text-5xl font-extrabold tracking-tight leading-tight">
              Respectful introductions. Real relationships.
            </h1>
            <p className="mt-5 text-lg text-neutral-700 max-w-prose">
              Mingling Hearts China connects considerate Western men (45–65) with kind, family‑minded Chinese women—
              focusing on safety, sincerity, and cultural respect at every step.
            </p>
            <ul className="mt-6 grid gap-3 text-sm text-neutral-800">
              <li className="flex items-start gap-3"><span className="mt-1 inline-block h-2.5 w-2.5 rounded-full bg-rose-600"/> Curated, hand‑checked profiles</li>
              <li className="flex items-start gap-3"><span className="mt-1 inline-block h-2.5 w-2.5 rounded-full bg-rose-600"/> Bilingual coaching & translation</li>
              <li className="flex items-start gap-3"><span className="mt-1 inline-block h-2.5 w-2.5 rounded-full bg-rose-600"/> Privacy and identity verification</li>
            </ul>
            <div className="mt-8 flex flex-wrap items-center gap-4">
              <a href="#contact" className="inline-flex items-center justify-center rounded-full bg-rose-600 px-6 py-3 font-semibold text-white shadow hover:bg-rose-700">Apply for a consultation</a>
              <a href="#how" className="inline-flex items-center justify-center rounded-full border border-neutral-300 px-6 py-3 font-semibold hover:bg-neutral-100">How it works</a>
            </div>
          </div>
          <div className="relative">
            <div className="aspect-[4/3] rounded-2xl bg-gradient-to-br from-rose-100 to-rose-200 shadow-inner overflow-hidden">
              <img src="https://images.unsplash.com/photo-1544025162-d76694265947?q=80&w=1600&auto=format&fit=crop" alt="Elegant couple walking in city at sunset" className="h-full w-full object-cover opacity-90"/>
            </div>
            <div className="absolute -bottom-6 -right-6 hidden sm:block">
              <div className="rounded-2xl bg-white shadow-xl p-4 w-64">
                <p className="text-sm font-semibold">Private, guided introductions</p>
                <p className="text-xs text-neutral-600 mt-1">From first hello to first visit—done thoughtfully.</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* How it works */}
      <section id="how" className="py-16 sm:py-24 bg-white">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <h2 className="text-3xl sm:text-4xl font-extrabold">How it works</h2>
          <div className="mt-10 grid gap-6 sm:grid-cols-2 lg:grid-cols-4">
            {[
              {title: '1) Apply', desc: 'Tell us about your values, lifestyle, and relationship goals.'},
              {title: '2) Verify', desc: 'ID + video verification for both sides to keep everyone safe.'},
              {title: '3) Match', desc: 'We curate thoughtful introductions with cultural guidance.'},
              {title: '4) Meet', desc: 'Video calls → in‑person visits when it feels right—no pressure.'},
            ].map((s, i) => (
              <div key={i} className="rounded-2xl border border-neutral-200 bg-neutral-50 p-6 shadow-sm">
                <div className="h-10 w-10 rounded-xl bg-rose-100 text-rose-700 font-bold flex items-center justify-center">{i+1}</div>
                <h3 className="mt-4 font-semibold">{s.title}</h3>
                <p className="mt-2 text-sm text-neutral-700">{s.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Values */}
      <section id="values" className="py-16 sm:py-24 bg-neutral-50">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <h2 className="text-3xl sm:text-4xl font-extrabold">Our values</h2>
          <div className="mt-10 grid gap-6 lg:grid-cols-3">
            {[
              {title: 'Respect', desc: 'Kindness, clarity, and sincerity guide every introduction.'},
              {title: 'Culture', desc: 'We honor traditions and help bridge language thoughtfully.'},
              {title: 'Safety', desc: 'Profile checks, moderation, and privacy‑first practices.'},
            ].map((v, i) => (
              <div key={i} className="rounded-2xl border border-neutral-200 bg-white p-6">
                <h3 className="font-semibold text-lg">{v.title}</h3>
                <p className="mt-2 text-neutral-700 text-sm">{v.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Stories */}
      <section id="stories" className="py-16 sm:py-24 bg-white">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <h2 className="text-3xl sm:text-4xl font-extrabold">Real stories</h2>
          <div className="mt-10 grid gap-6 lg:grid-cols-3">
            {[1,2,3].map((i)=> (
              <article key={i} className="rounded-2xl border border-neutral-200 p-6">
                <div className="aspect-[4/3] rounded-xl overflow-hidden bg-neutral-100">
                  <img src={`https://images.unsplash.com/photo-15${40+i}0-portrait?q=80&w=1200&auto=format&fit=crop`} alt="Happy couple" className="h-full w-full object-cover"/>
                </div>
                <h3 className="mt-4 font-semibold">“We took it slow—and it felt right.”</h3>
                <p className="mt-2 text-sm text-neutral-700">Guided video calls helped us build trust before meeting in person.</p>
              </article>
            ))}
          </div>
        </div>
      </section>

      {/* Safety */}
      <section id="safety" className="py-16 sm:py-24 bg-neutral-50">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <h2 className="text-3xl sm:text-4xl font-extrabold">Safety & privacy</h2>
          <div className="mt-8 grid gap-6 sm:grid-cols-2">
            <div className="rounded-2xl border border-neutral-200 bg-white p-6">
              <h3 className="font-semibold">Verification</h3>
              <p className="mt-2 text-sm text-neutral-700">We use multi‑step checks: government ID, liveness video, and reference screening.</p>
            </div>
            <div className="rounded-2xl border border-neutral-200 bg-white p-6">
              <h3 className="font-semibold">Moderation</h3>
              <p className="mt-2 text-sm text-neutral-700">Profiles and messages are monitored for scams, coercion, and disrespectful behavior.</p>
            </div>
          </div>

          <details className="mt-8 group rounded-2xl border border-neutral-200 bg-white p-6">
            <summary className="cursor-pointer list-none font-semibold flex items-center justify-between">
              Frequently asked questions
              <span className="ml-4 inline-block rotate-0 group-open:rotate-180 transition">
                <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor"><path fillRule="evenodd" d="M5.23 7.21a.75.75 0 011.06.02L10 10.94l3.71-3.71a.75.75 0 111.06 1.06l-4.24 4.24a.75.75 0 01-1.06 0L5.21 8.29a.75.75 0 01.02-1.08z" clipRule="evenodd"/></svg>
              </span>
            </summary>
            <div className="mt-4 grid gap-4 text-sm text-neutral-700">
              <p><strong>Is this a dating app?</strong> No. We provide curated introductions with real human guidance—not swiping.</p>
              <p><strong>Do you coach communication?</strong> Yes, we offer bilingual coaching and cultural context at each stage.</p>
              <p><strong>Is travel required?</strong> Only when both sides feel ready; we support safe planning.</p>
            </div>
          </details>
        </div>
      </section>

      {/* Contact */}
      <section id="contact" className="py-16 sm:py-24 bg-white">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <div className="grid lg:grid-cols-2 gap-10">
            <div>
              <h2 className="text-3xl sm:text-4xl font-extrabold">Apply for a private consultation</h2>
              <p className="mt-4 text-neutral-700">Answer a few questions and we’ll reach out within 24–48 hours.</p>
              <ul className="mt-6 space-y-2 text-sm">
                <li>• Discreet, one‑on‑one guidance</li>
                <li>• Transparent pricing after your fit interview</li>
                <li>• Serves US/Canada/UK/Australia clients</li>
              </ul>
            </div>

            <form
              className="rounded-2xl border border-neutral-200 p-6 shadow-sm bg-neutral-50"
              onSubmit={(e)=>{ e.preventDefault(); alert('Thanks! We\'ll be in touch shortly.'); }}
            >
              <div className="grid gap-4">
                <label className="grid gap-1">
                  <span className="text-sm font-medium">Full name</span>
                  <input required type="text" className="rounded-xl border border-neutral-300 px-3 py-2 outline-none focus:ring-2 focus:ring-rose-500" placeholder="John Smith"/>
                </label>
                <label className="grid gap-1">
                  <span className="text-sm font-medium">Email</span>
                  <input required type="email" className="rounded-xl border border-neutral-300 px-3 py-2 outline-none focus:ring-2 focus:ring-rose-500" placeholder="john@example.com"/>
                </label>
                <label className="grid gap-1">
                  <span className="text-sm font-medium">Age</span>
                  <input required type="number" min="18" className="rounded-xl border border-neutral-300 px-3 py-2 outline-none focus:ring-2 focus:ring-rose-500" placeholder="52"/>
                </label>
                <label className="grid gap-1">
                  <span className="text-sm font-medium">What are you looking for?</span>
                  <textarea rows={4} className="rounded-xl border border-neutral-300 px-3 py-2 outline-none focus:ring-2 focus:ring-rose-500" placeholder="Share a bit about your values and goals..."/>
                </label>
                <button className="mt-2 rounded-full bg-rose-600 px-5 py-3 font-semibold text-white hover:bg-rose-700">Submit</button>
                <p className="text-xs text-neutral-500">By submitting, you agree to our respectful conduct policy.</p>
              </div>
            </form>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t border-neutral-200 bg-neutral-50">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 py-10 flex flex-col sm:flex-row items-center justify-between gap-4">
          <p className="text-sm text-neutral-600">© {new Date().getFullYear()} Mingling Hearts China. All rights reserved.</p>
          <div className="flex items-center gap-6 text-sm">
            <a href="#" className="hover:text-rose-700">Privacy</a>
            <a href="#" className="hover:text-rose-700">Terms</a>
            <a href="#contact" className="hover:text-rose-700">Contact</a>
          </div>
        </div>
      </footer>
    </div>
  );
}
