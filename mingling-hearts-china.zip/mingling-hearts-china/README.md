# Mingling Hearts China (Next.js + Tailwind)

This is a ready-to-deploy Next.js project for **MinglingHeartsChina.com**.

## Quick start

```bash
npm install
npm run dev
# open http://localhost:3000
```

## Deploy to Vercel
1. Create a GitHub repo and push this folder.
2. Go to Vercel → New Project → Import the repo.
3. Click **Deploy** (defaults are fine).
4. Point your domain `minglingheartschina.com` to Vercel (add the domain in Vercel → follow DNS instructions).

_Generated on 2025-10-12._
